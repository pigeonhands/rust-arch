pub mod aur;
#[macro_use]
extern crate lazy_static;
extern crate reqwest;